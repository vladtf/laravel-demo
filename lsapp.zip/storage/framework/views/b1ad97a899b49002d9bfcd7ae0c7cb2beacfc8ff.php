<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\lsapp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>