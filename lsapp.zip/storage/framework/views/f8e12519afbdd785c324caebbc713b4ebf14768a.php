<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">Dashboard</div>
                    <h1 class="card-header">Your Blog Posts</h1>
                    <a href="/posts/create" class="page-link" role="button">Create a new post</a>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>

                        <?php endif; ?>

                        <table class="table table-striped">
                            <tr>
                                <th class="tab-content">Title</th>
                                <th></th>
                                <th></th>
                            </tr>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="/posts/<?php echo e($post->id); ?>" class="card-link"><?php echo e($post->title); ?></a></td>
                                    <td><a href="/posts/<?php echo e($post->id); ?>/edit" class="card-link">Edit</a></td>
                                    <td>
                                        <?php echo Form::open(['action' => ['PostController@destroy', $post->id],'method'=>'POST', 'class'=> 'form-inline float-sm-right']); ?>

                                        <?php echo e(Form::hidden('_method','DELETE')); ?>

                                        <?php echo e(Form::submit('Delete', ['class'=>'btn btn-outline-danger btn-sm'])); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lsapp\resources\views/home.blade.php ENDPATH**/ ?>