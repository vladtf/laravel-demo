<?php $__env->startSection('content'); ?>
    <a href="/posts" style="margin-bottom: 20px;" class="btn btn-light btn-outline-info">Go Back</a>
    <h1 class="card-header"><?php echo e($post->title); ?></h1>
    <img style="width: 100%;" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" >
    <br>
    <br>
    <div class="card-body">
        <?php echo $post->body; ?>

    </div>
    <hr>
    <small>Written on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
    <hr>
    <?php if(!Auth::guest() && $post->user_id == Auth::user()->id): ?>
        <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit</a>

        <?php echo Form::open(['action' => ['PostController@destroy', $post->id],'method'=>'POST', 'class'=> 'form-inline float-sm-right']); ?>

        <?php echo e(Form::hidden('_method','DELETE')); ?>

        <?php echo e(Form::submit('Delete', ['class'=>'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\lsapp\resources\views/posts/show.blade.php ENDPATH**/ ?>